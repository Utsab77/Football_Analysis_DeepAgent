const fs = require('fs');
const path = require('path');
const { Document, Packer, Paragraph, TextRun, AlignmentType, TabStopType } = require('docx');

const BASE_URL = 'https://hamrocsit.com';
const SEMESTERS = {
  2: { name: 'Second', folder: 'BSc_CSIT_2nd_Semester_Output',
    subjects: { 'CSC165': { name: 'Discrete Structure', slug: 'ds' }, 'CSC166': { name: 'Object-Oriented Programming', slug: 'oops' }, 'CSC167': { name: 'Microprocessor', slug: 'microprocessor' }, 'MTH168': { name: 'Mathematics II', slug: 'mathii' }, 'STA169': { name: 'Statistics I', slug: 'stat-i' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  3: { name: 'Third', folder: 'BSc_CSIT_3rd_Semester_Output',
    subjects: { 'CSC211': { name: 'Data Structure and Algorithm', slug: 'dsa' }, 'CSC212': { name: 'Numerical Method', slug: 'csc207' }, 'CSC213': { name: 'Computer Architecture', slug: 'csc208' }, 'CSC214': { name: 'Computer Graphics', slug: 'csc209' }, 'STA215': { name: 'Statistics II', slug: 'stat-ii' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  4: { name: 'Fourth', folder: 'BSc_CSIT_4th_Semester_Output',
    subjects: { 'CSC262': { name: 'Theory of Computation', slug: 'toc' }, 'CSC263': { name: 'Computer Networks', slug: 'cn' }, 'CSC264': { name: 'Operating System', slug: 'os' }, 'CSC265': { name: 'Database Management System', slug: 'dbms' }, 'CSC266': { name: 'Artificial Intelligence', slug: 'ai' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  5: { name: 'Fifth', folder: 'BSc_CSIT_5th_Semester_Output',
    subjects: { 'CSC314': { name: 'Design and Analysis of Algorithms', slug: 'daa' }, 'CSC315': { name: 'System Analysis and Design', slug: 'sad' }, 'CSC316': { name: 'Cryptography', slug: 'cryptography' }, 'CSC317': { name: 'Simulation and Modeling', slug: 'sm' }, 'CSC318': { name: 'Web Technology', slug: 'web-tech' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  6: { name: 'Sixth', folder: 'BSc_CSIT_6th_Semester_Output',
    subjects: { 'CSC364': { name: 'Software Engineering', slug: 'se' }, 'CSC365': { name: 'Compiler Design and Construction', slug: 'cdc' }, 'CSC366': { name: 'E-Governance', slug: 'e-governance' }, 'CSC367': { name: 'NET Centric Computing', slug: 'ncc' }, 'CSC370': { name: 'E-Commerce', slug: 'e-commerce' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  7: { name: 'Seventh', folder: 'BSc_CSIT_7th_Semester_Output',
    subjects: { 'CSC409': { name: 'Advanced Java Programming', slug: 'advanced-java' }, 'CSC410': { name: 'Data Warehousing and Data Mining', slug: 'data-mining' }, 'CSC412': { name: 'Project Work', slug: 'project-work' }, 'CSC413': { name: 'Information Retrieval', slug: 'information-retrieval' }, 'CSC415': { name: 'Software Project Management', slug: 'software-project-management' }, 'CSC416': { name: 'Network Security', slug: 'network-security' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  8: { name: 'Eight', folder: 'BSc_CSIT_8th_Semester_Output',
    subjects: { 'CSC461': { name: 'Advanced Database', slug: 'advanced-database' }, 'CSC463': { name: 'Advanced Networking with IPV6', slug: 'advanced-networking-with-ipv6' }, 'CSC465': { name: 'Game Technology', slug: 'game-technology' }, 'CSC467': { name: 'Introduction to Cloud Computing', slug: 'introduction-to-cloud-computing' }, 'CSC470': { name: 'Mobile Application Development', slug: 'mobile-application-development' }, 'CSC471': { name: 'Real Time Systems', slug: 'real-time-systems' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] }
};

function decodeEntities(t) {
  return t.replace(/&#8211;/g, '\u2013').replace(/&#8212;/g, '\u2014').replace(/&#8216;/g, '\u2018')
    .replace(/&#8217;/g, '\u2019').replace(/&#8220;/g, '\u201C').replace(/&#8221;/g, '\u201D')
    .replace(/&#8230;/g, '\u2026').replace(/&#8722;/g, '\u2212').replace(/&#\d+;/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').trim();
}

function cleanLatex(t) {
  t = t.replace(/\$\$/g, '').replace(/\\\[/g, '').replace(/\\\]/g, '');
  t = t.replace(/\\\(/g, '').replace(/\\\)/g, '');
  t = t.replace(/\\vspace\{[^}]*\}/g, '\n').replace(/\\hspace\{[^}]*\}/g, ' ');
  t = t.replace(/\\quad/g, '    ').replace(/\\qquad/g, '        ');
  t = t.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1)/($2)');
  t = t.replace(/\\sqrt\{([^}]+)\}/g, 'sqrt($1)');
  t = t.replace(/\\text\{([^}]*)\}/g, '$1').replace(/\\mathbf\{([^}]*)\}/g, '$1');
  t = t.replace(/\\left\(/g, '(').replace(/\\right\)/g, ')');
  t = t.replace(/\\left\[/g, '[').replace(/\\right\]/g, ']');
  t = t.replace(/\\rightarrow/g, '\u2192').replace(/\\leftarrow/g, '\u2190');
  t = t.replace(/\\leq/g, '\u2264').replace(/\\geq/g, '\u2265').replace(/\\neq/g, '\u2260');
  t = t.replace(/\\in/g, '\u2208').replace(/\\forall/g, '\u2200').replace(/\\exists/g, '\u2203');
  t = t.replace(/\\cup/g, '\u222A').replace(/\\cap/g, '\u2229');
  t = t.replace(/\\cdot/g, '\u00B7').replace(/\\times/g, '\u00D7').replace(/\\div/g, '\u00F7');
  t = t.replace(/\\pm/g, '\u00B1');
  t = t.replace(/\\alpha/g, '\u03B1').replace(/\\beta/g, '\u03B2').replace(/\\gamma/g, '\u03B3');
  t = t.replace(/\\delta/g, '\u03B4').replace(/\\epsilon/g, '\u03B5').replace(/\\theta/g, '\u03B8');
  t = t.replace(/\\lambda/g, '\u03BB').replace(/\\mu/g, '\u03BC').replace(/\\pi/g, '\u03C0');
  t = t.replace(/\\sigma/g, '\u03C3').replace(/\\tau/g, '\u03C4').replace(/\\phi/g, '\u03C6');
  t = t.replace(/\\omega/g, '\u03C9').replace(/\\rho/g, '\u03C1');
  t = t.replace(/_\{([^}]+)\}/g, (m, p1) => p1.split('').map(c => {
    const s = {'0':'\u2080','1':'\u2081','2':'\u2082','3':'\u2083','4':'\u2084','5':'\u2085','6':'\u2086','7':'\u2087','8':'\u2088','9':'\u2089','n':'\u2099'};
    return s[c] || c;
  }).join(''));
  t = t.replace(/_([0-9n])/g, (m, p1) => {
    const s = {'0':'\u2080','1':'\u2081','2':'\u2082','3':'\u2083','4':'\u2084','5':'\u2085','6':'\u2086','7':'\u2087','8':'\u2088','9':'\u2089','n':'\u2099'};
    return s[p1] || p1;
  });
  t = t.replace(/\^\{([^}]+)\}/g, (m, p1) => p1.split('').map(c => {
    const s = {'0':'\u2070','1':'\u00B9','2':'\u00B2','3':'\u00B3','4':'\u2074','5':'\u2075','6':'\u2076','7':'\u2077','8':'\u2078','9':'\u2079'};
    return s[c] || c;
  }).join(''));
  t = t.replace(/\^([0-9])/g, (m, p1) => {
    const s = {'0':'\u2070','1':'\u00B9','2':'\u00B2','3':'\u00B3','4':'\u2074','5':'\u2075','6':'\u2076','7':'\u2077','8':'\u2078','9':'\u2079'};
    return s[p1] || p1;
  });
  t = t.replace(/\\[a-zA-Z]+/g, '');
  t = t.replace(/\{([^{}]*)\}/g, '$1');
  return t.replace(/\s{2,}/g, ' ').trim();
}

function parseQuestions(html) {
  const sections = [];
  const sectionRegex = /<strong>(SECTION\s+[A-Z])<\/strong><\/p><p><strong>(.*?)<\/strong>/gi;
  const sectionBounds = [];
  let sm;
  while ((sm = sectionRegex.exec(html)) !== null) {
    sectionBounds.push({ title: sm[1], instruction: decodeEntities(sm[2].replace(/<[^>]+>/g, '')), start: sm.index, questions: [] });
  }
  const jsonMatch = html.match(/const qnbankdata = ({[\s\S]*?});\s*(?:const|document|\/\/)/);
  if (!jsonMatch) return sections;
  let qnbankdata;
  try { qnbankdata = JSON.parse(jsonMatch[1]); } catch (e) { return sections; }
  const indexRegex = /data-id="(\d+)" data-index="(\d+)"/g;
  const questionOrder = [];
  let im;
  while ((im = indexRegex.exec(html)) !== null) { questionOrder.push({ id: im[1], index: parseInt(im[2]) }); }
  const allQuestions = [];
  for (const item of questionOrder) {
    const q = qnbankdata[item.id];
    if (q) allQuestions.push({ number: allQuestions.length + 1, text: decodeEntities(cleanLatex(q.rawtitle || '')), id: item.id });
  }
  if (sectionBounds.length === 0 && allQuestions.length > 0) {
    sectionBounds.push({ title: 'Questions', instruction: '', start: 0, questions: allQuestions });
  }
  const sectionRanges = [];
  for (let i = 0; i < sectionBounds.length; i++) {
    const start = sectionBounds[i].start;
    const end = i + 1 < sectionBounds.length ? sectionBounds[i + 1].start : html.length;
    sectionRanges.push({ section: sectionBounds[i], start, end });
  }
  for (const q of allQuestions) {
    const qPos = html.indexOf('data-id="' + q.id + '"');
    if (qPos === -1) continue;
    for (const range of sectionRanges) {
      if (qPos >= range.start && qPos < range.end) {
        q.number = range.section.questions.length + 1;
        range.section.questions.push(q);
        break;
      }
    }
  }
  for (const range of sectionRanges) {
    if (range.section.questions.length > 0) {
      sections.push({ title: range.section.title, instruction: range.section.instruction, questions: range.section.questions });
    }
  }
  return sections;
}

async function genDocx(semNum, code, name, year, sections) {
  const semName = SEMESTERS[semNum].name;
  const ch = [];
  ch.push(new Paragraph({ spacing: { after: 100 }, children: [] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: 'Tribhuvan University', bold: true, size: 32, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: 'Institute of Science and Technology', bold: true, size: 28, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, children: [new TextRun({ text: 'Bachelor Level / ' + semName.toLowerCase() + ' semester / Science', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: 'Computer Science and Information Technology (' + code + ')', bold: true, size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: name, bold: true, size: 32, font: 'Times New Roman' })] }));
  const yd = year.includes('new') ? year.split('-')[0] + ' (New Syllabus)' : year;
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: yd + ' (BS)', bold: true, size: 28, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 }, children: [new TextRun({ text: 'Question Bank', bold: true, size: 26, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: 'Full Marks: 60 + 20 + 20', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: 'Pass Marks: 24 + 8 + 8', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: 'Time: 3 Hours', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: 'Candidates are required to give their answers in their own words as far as practicable.', italics: true, size: 22, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: 'The figures in the margin indicate full marks.', italics: true, size: 22, font: 'Times New Roman' })] }));
  for (const sec of sections) {
    ch.push(new Paragraph({ spacing: { before: 200, after: 80 }, children: [new TextRun({ text: sec.title, bold: true, size: 26, font: 'Times New Roman' })] }));
    if (sec.instruction) ch.push(new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: sec.instruction, italics: true, size: 24, font: 'Times New Roman' })] }));
    for (const q of sec.questions) {
      ch.push(new Paragraph({ spacing: { after: 100 }, tabStops: [{ type: TabStopType.LEFT, position: 720 }],
        children: [new TextRun({ text: q.number + '.', bold: true, size: 24, font: 'Times New Roman' }), new TextRun({ text: '\t', size: 24 }), new TextRun({ text: q.text, size: 24, font: 'Times New Roman' })] }));
    }
  }
  const doc = new Document({ sections: [{ properties: { page: { margin: { top: 1440, right: 1296, bottom: 1440, left: 1296 } } }, children: ch }] });
  return doc;
}

async function run() {
  const base = 'C:\\Users\\Acer\\Desktop\\CSIT';
  let total = 0, errs = 0;
  for (const [sn, sd] of Object.entries(SEMESTERS)) {
    const sf = path.join(base, sd.folder);
    if (!fs.existsSync(sf)) fs.mkdirSync(sf, { recursive: true });
    console.log('\n=== SEMESTER ' + sn + ': ' + sd.name.toUpperCase() + ' ===');
    for (const [code, subj] of Object.entries(sd.subjects)) {
      const sdir = path.join(sf, code + '_' + subj.name.replace(/\s+/g, '_'));
      if (!fs.existsSync(sdir)) fs.mkdirSync(sdir, { recursive: true });
      process.stdout.write('  ' + code + ': ');
      let semTotal = 0;
      for (const year of sd.years) {
        const url = BASE_URL + '/semester/' + sd.name.toLowerCase() + '/' + subj.slug + '/question-bank/' + year + '/';
        try {
          const resp = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
          if (!resp.ok) { process.stdout.write(year.slice(-2) + '(x) '); continue; }
          const html = await resp.text();
          const sections = parseQuestions(html);
          if (sections.length === 0) { process.stdout.write(year.slice(-2) + '(-) '); continue; }
          const tq = sections.reduce((s, sec) => s + sec.questions.length, 0);
          const doc = await genDocx(parseInt(sn), code, subj.name, year, sections);
          const yc = year.replace('-', '_');
          const fn = sd.name + '_Semester_' + code + '_' + subj.name.replace(/\s+/g, '_') + '_' + yc + '.docx';
          const buf = await Packer.toBuffer(doc);
          fs.writeFileSync(path.join(sdir, fn), buf);
          process.stdout.write(year.slice(-2) + '(' + tq + 'Q) ');
          semTotal++;
          total++;
          await new Promise(r => setTimeout(r, 200));
        } catch (e) { process.stdout.write(year.slice(-2) + '(err) '); errs++; }
      }
      console.log(' [' + semTotal + ' files]');
    }
  }
  console.log('\n=== DONE: ' + total + ' files, ' + errs + ' errors ===');
}
run().catch(console.error);
