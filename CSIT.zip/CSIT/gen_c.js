const docx = require("docx");
const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, AlignmentType } = docx;

function makeDoc(title, code, subject, year, sections) {
  const children = [];
  const h = (text, bold, size) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text, bold, size })] });
  const p = (text, opts={}) => new Paragraph({ spacing: opts.spacing || { after: 100 }, indent: opts.indent, children: [new TextRun({ text, size: opts.size||22, bold: opts.bold, italics: opts.italics })] });
  children.push(h("Tribhuvan University", true, 28));
  children.push(h("Institute of Science and Technology", true, 24));
  children.push(h(String(year), true, 28));
  children.push(h("Bachelor Level / first-semester / Science", false, 22));
  children.push(h(subject+"( "+code+" )", true, 22));
  children.push(h(title, true, 26));
  children.push(h("Full Marks: 60 + 20 + 20", false, 22));
  children.push(h("Pass Marks: 24 + 8 + 8", false, 22));
  children.push(h("Time: 3 Hours", false, 22));
  children.push(p("Candidates are required to give their answers in their own words as far as practicable.", { size: 20, italics: true, spacing: { after: 200 } }));
  children.push(p("The figures in the margin indicate full marks.", { size: 20, italics: true, spacing: { after: 200 } }));
  for (const sec of sections) {
    children.push(p(sec.title, { bold: true, size: 24, spacing: { before: 300, after: 100 } }));
    if (sec.instruction) children.push(p(sec.instruction, { bold: true, italics: true, size: 22, spacing: { after: 200 } }));
    for (const q of sec.questions) {
      children.push(p(String(q.n), { bold: true, size: 22, spacing: { before: 200, after: 100 } }));
      children.push(p(q.t, { size: 22, indent: { left: 360 } }));
    }
  }
  return Packer.toBuffer(new Document({ sections: [{ children }] }));
}

const c = {
  2081: [
    { title: "SECTION A", instruction: "Answer any TWO questions.", questions: [
      { n: 1, t: "List different types of operators and explain any four of them." },
      { n: 2, t: "What are the characteristics of array? Write a program to input age of 500 persons and display the following\n1. Average age\n2. Age between 25 to 30" },
      { n: 3, t: "Differentiate between library function and user defined function. Write a program to swap two values using call by refrence concept." }
    ]},
    { title: "SECTION B", instruction: "Answer any EIGHT questions.", questions: [
      { n: 4, t: "Explain the basic structure of C Programming." },
      { n: 5, t: "Describe different formatted input and output functions. Why do we use them?" },
      { n: 6, t: "Write a program to display first 50 prime numbers." },
      { n: 7, t: "Write a program to display the following series up to 25 terms but do not print the 7th term. 2 x 3, 3 x 5, 4 x 7, 5 x 9..." },
      { n: 8, t: "Demonstrate the use of recursive function with a suitable example." },
      { n: 9, t: "Create a structure called STUDENT with data members SID, name, address, CGPA. Write a program to initialize the value of 100 students and display the information of those students whose address is \"KTM\" and CGPA is between 3.5 to 4. using C program" },
      { n: 10, t: "Explain different file opening modes." },
      { n: 11, t: "Write a program to draw two shapes of your choice using graphics function." },
      { n: 12, t: "Write short notes on:\na) Global variable\nb) Debugging" }
    ]}
  ],
  2080: [
    { title: "Section A", instruction: "Attempt any two questions.", questions: [
      { n: 1, t: "Define structure and nested structure. Write a program to find out whether the nth term of the Fibonacci series is a prime number or not. Read the value of n from the user and display the result in the main function. Uses separate user-defined function to generate the nth Fibonacci term and to check whether that number is prime or not." },
      { n: 2, t: "Explain the relation to array and pointer. Differentiate call by value and call by reference with a suitable program." },
      { n: 3, t: "Differentiate between source code and object code. Create a structure named Book with members Book_Name, Price and Author_Name, then take input for 10 records of Book and print the name of authors having the price of book greater than 1000." }
    ]},
    { title: "Section B", instruction: "Attempt any eight questions.", questions: [
      { n: 4, t: "Describe the different types of I/O functions used in file handling with syntax." },
      { n: 5, t: "Write a program to read P*Q matrix of integers and find the largest integer of each row and display it." },
      { n: 6, t: "Write a program to calculate the factorial of a given number using recursion." },
      { n: 7, t: "Write a program to check whether the entered word is pallindrome or not." },
      { n: 8, t: "List different types of operators and explain any three of them." },
      { n: 9, t: "Trace the output:\n#include<conio.h>\n#include<stdio.h>\nvoid main(){\nint i=0,k;\nfor(k=5;k>=0;k--){\ni=i+k;\n}\nprintf(\"%d\\t\",i);\ngetch();\n}" },
      { n: 10, t: "Write a program to compute the sum of first 10 even numbers using function." },
      { n: 11, t: "What is dynamic memory allocation? Explain with a suitable program." },
      { n: 12, t: "Write a program to initialize an array of dimension 10 and sort the numbers within the array in ascending order." }
    ]}
  ],
  2079: [
    { title: "Section A", instruction: "Attempts any two questions:", questions: [
      { n: 1, t: "What is the difference between exit(0) and exit(1)? Discuss the need of nested structue with an example. Write a program to find the value of xy without using POW code." },
      { n: 2, t: "Why do we need a break and continue statement? Define formal argument and actual argument in function with examples. Identify and list the errors in the following code.\n\nint main(){\n    int a,b,c\n    scanf(\"%d%d%d, &a, &b, &c);\n    sum(a, b, c);\n    return -1;\n}\n\nvoid sum(int x, int y, int z){\n    int sum;\n    sum = a + b + c;\n    return sum;\n}" },
      { n: 3, t: "Write a program to demonstrate the following menu-driven program. The user will provide an integer and alphabet for making choice and the corresponding task has to be performed according as follow:\n1. Find Odd or Even\n2. Find Positive or Negative\n3. Find the Factorial value\n4. Exit\nThe choice will be displayed until the user will give \"D\" as a choice." }
    ]},
    { title: "Section B", instruction: "Attempts any eight questions:", questions: [
      { n: 4, t: "How do you swap the values of two integers without using the third temporary variable? Justify with the example." },
      { n: 5, t: "Write a program to find the sum of digits of a given integer using recursion." },
      { n: 6, t: "Differentiate between constant and literals. Why do we need to define the type of data?" },
      { n: 7, t: "Write a program to find the second largest number in the given array of numbers." },
      { n: 8, t: "Create a structure \"Employee\" having Name, Address, Salary, and Age as member functions. Display the name of the employee having aged between 40 and 50 are living in Kathmandu." },
      { n: 9, t: "List any one advantage and disadvantage of the pointer. How do you pass pointers as function arguments?" },
      { n: 10, t: "Suppose a file named \"Num.txt\" contains a list of integers. Write a program to extract the prime numbers only from that file and write them on \"Prime.txt\" file." },
      { n: 11, t: "What is the advantage of the union over structure? List any four-string library functions with the prototype." },
      { n: 12, t: "Write short notes on:\na) Local, Global, and Static variables\nb) Conditional Operator" }
    ]}
  ],
  2078: [
    { title: "Section A", instruction: "Attempts any two questions:", questions: [
      { n: 1, t: "What do you mean by jump statement? Explain each jump statement with example. Write a program to check whether a number entered is prime or not." },
      { n: 2, t: "Explain any three string functions. Write a program to check if two matrices are identical or act." },
      { n: 3, t: "Define structure. Explain nested structure with example. Create a structure named book with name, author, and publisher as its members. Write a program using this structure to read data of 50 books and display name of those books published by \"XYX\" publisher." }
    ]},
    { title: "Section B", instruction: "Attempts any eight questions:", questions: [
      { n: 4, t: "Discuss structure of a C Program with suitable example." },
      { n: 5, t: "What is variable? How is it different from constant? How do you write comments in c?" },
      { n: 6, t: "Explain formatted I/O functions in detail." },
      { n: 7, t: "Write a program using your own function to find sum of two numbers" },
      { n: 8, t: "Write a program to print largest among three numbers entered by the user." },
      { n: 9, t: "Explain dynamic memory allocation with example" },
      { n: 10, t: "Write a program that simply reads data from a file" },
      { n: 11, t: "Write a program to draw a line using graphics function." },
      { n: 12, t: "Write short notes on:\na) History of C\nb) Bitwise Operator" }
    ]}
  ],
  2077: [
    { title: "Section A", instruction: "Attempt any two questions: (2x10=20)", questions: [
      { n: 1, t: "What do you mean by looping? Explain while loop with suitable example. Compare while loop with do-while loop. Write a program to find sum and average of first n natural numbers." },
      { n: 2, t: "What are the benefits of using arrays? Compare one dimensional array with two dimensional array. Write a program to find transpose of a matrix." },
      { n: 3, t: "What is structure? How is it different from union? Create a structure named course with name, code, and credit_hour as its members. Write a program using this structure to read data of 5courses and display data of those curses with credit_hour greater than 3." }
    ]},
    { title: "Section B", instruction: "Attempt any eight questions: (8x5=40)", questions: [
      { n: 4, t: "Explain flowchart with example. What are the benefits of using flowcharts?" },
      { n: 5, t: "What is data type? Why do we need it in programming? Explain any three basic data types with example." },
      { n: 6, t: "What do you mean by unformatted I/O? Explain" },
      { n: 7, t: "Write a program to display first n prime numbers." },
      { n: 8, t: "Write a program to find product of two integers using your own function." },
      { n: 9, t: "Define pointer. Flow to you return pointers from functions? Explain with example." },
      { n: 10, t: "Explain different file I/O functions with example." },
      { n: 11, t: "Write a program to draw a circle using graphics function" },
      { n: 12, t: "Write short notes on\na) Compilation and execution\nb) Operator precedence and associativity" }
    ]}
  ],
  2075: [
    { title: "Section A", instruction: "Attempts any two Questions (2 x 10 = 20)", questions: [
      { n: 1, t: "What is looping statement? Discuss different looping statements with suitable example of each." },
      { n: 2, t: "Define array? What are the benefits of using array? Write a program to add two matrices using array." },
      { n: 3, t: "Why do we need data files? What are the different file opening modes? Write a program that reads data from a file \"input.txt\" and writes to \"output.txt\" file." }
    ]},
    { title: "Section B", instruction: "Attempts any eight Questions (8 x 5 = 40)", questions: [
      { n: 4, t: "Discuss different logical operation in detail." },
      { n: 5, t: "What is break statement? Discuss with example. How the break statement is different from continue statement?" },
      { n: 6, t: "Write a program to check whether a number entered is even or odd." },
      { n: 7, t: "Write a program to calculate sum of first 10 odd numbers." },
      { n: 8, t: "What is preprocessor directives? Discuss # define directive with example." },
      { n: 9, t: "Discuss any five string library functions." },
      { n: 10, t: "What is dynamic memory allocation? Discuss the use of malloc() in dynamic memory allocation with example." },
      { n: 11, t: "What is structure? Create a structure rectangle with data members length and breadth." },
      { n: 12, t: "Write short notes on:\na) Benefits of data files\nb) Graphics functions" }
    ]}
  ],
  2074: [
    { title: "Section A", instruction: "Attempts any two questions (2 x 10 = 20)", questions: [
      { n: 1, t: "Discuss structure of a C Program with suitable example." },
      { n: 2, t: "Discuss different types of if statements with example of each. Differentiate if statement with switch statement." },
      { n: 3, t: "What is structure? How is it different from array? Create a structure student having data members name, roll-number and percentage. Complete the program to display the name of student having percentage greater than or equal to 60." }
    ]},
    { title: "Section B", instruction: "Attempts any eight questions (8 x 5 = 40)", questions: [
      { n: 4, t: "What is algorithm? How is it different from flow chart?" },
      { n: 5, t: "What is type conversion? Discuss type casting with suitable example." },
      { n: 6, t: "Discuss increment and decrement operators with example." },
      { n: 7, t: "Write a program that computes the sum of digits of a given integer number" },
      { n: 8, t: "What is function? Discuss the benefits of using function." },
      { n: 9, t: "Write a program to find sum and average of 10 integer numbers stored in an array." },
      { n: 10, t: "Define pointer. Discuss the relationship between pointer and one-dimensional array" },
      { n: 11, t: "Write a program to read and print data stored in a file input.txt." },
      { n: 12, t: "Why do we need graphics functions? Write a program to draw a circle." }
    ]}
  ]
};

const dir = "BSc_CSIT_1st_Semester_Output/CSC115_C_Programming";
fs.mkdirSync(dir, { recursive: true });

(async () => {
  for (const [year, sections] of Object.entries(c)) {
    const buf = await makeDoc("C Programming", "CSC115", "Computer Science and Information Technology", year, sections);
    const f = dir + "/1st_Semester_CSC115_C_Programming_" + year + ".docx";
    fs.writeFileSync(f, buf);
    console.log("Created:", f);
  }
  console.log("C Programming done!");
})();
