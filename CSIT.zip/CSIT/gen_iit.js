const docx = require("docx");
const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, AlignmentType } = docx;

function makeDoc(title, code, subject, year, sections) {
  const children = [];
  const h = (text, bold, size, center=true) => new Paragraph({ alignment: center ? AlignmentType.CENTER : AlignmentType.LEFT, spacing: { after: 100 }, children: [new TextRun({ text, bold, size })] });
  const p = (text, opts={}) => new Paragraph({ spacing: opts.spacing || { after: 100 }, indent: opts.indent, children: [new TextRun({ text, size: opts.size||22, bold: opts.bold, italics: opts.italics })] });

  children.push(h("Tribhuvan University", true, 28));
  children.push(h("Institute of Science and Technology", true, 24));
  children.push(h(String(year), true, 28));
  children.push(h("Bachelor Level / first-semester / Science", false, 22));
  children.push(h(subject+"( "+code+" )", true, 22));
  children.push(h(title, true, 26));
  children.push(h("Full Marks: 60 + 20 + 20", false, 22));
  children.push(h("Pass Marks: 24 + 8 + 8", false, 22));
  children.push(h("Time: 3 Hours", false, 22));
  children.push(p("Candidates are required to give their answers in their own words as far as practicable.", { size: 20, italics: true, spacing: { after: 200 } }));
  children.push(p("The figures in the margin indicate full marks.", { size: 20, italics: true, spacing: { after: 200 } }));

  for (const sec of sections) {
    children.push(p(sec.title, { bold: true, size: 24, spacing: { before: 300, after: 100 } }));
    if (sec.instruction) children.push(p(sec.instruction, { bold: true, italics: true, size: 22, spacing: { after: 200 } }));
    for (const q of sec.questions) {
      children.push(p(String(q.n), { bold: true, size: 22, spacing: { before: 200, after: 100 } }));
      children.push(p(q.t, { size: 22, indent: { left: 360 } }));
    }
  }
  return Packer.toBuffer(new Document({ sections: [{ children }] }));
}

const iit = {
  2081: [
    { title: "SECTION A", instruction: "Attempt any TWO questions.", questions: [
      { n: 1, t: "Compare primary memory with secondary memory. Why do we need primary memory in computers? Explain different types of secondary memories used in computer." },
      { n: 2, t: "Explain application software with example. Why do we need system software in computer?What are different type of operating system?" },
      { n: 3, t: "Define network topology. Explain different types of network topologies along with their merit and demerit." }
    ]},
    { title: "SECTION B", instruction: "Attempt any EIGHT questions.", questions: [
      { n: 4, t: "Explain different characteristics of computers." },
      { n: 5, t: "Explain instruction format with example. What is instruction set?" },
      { n: 6, t: "What is I/O port? Explain working of I/O system." },
      { n: 7, t: "What is Unicode? Convert 0.865 from Base 10 to Base 16." },
      { n: 8, t: "Explain cloud computing in brief." },
      { n: 9, t: "What is data warehouse? Explain." },
      { n: 10, t: "What are different element of multimedia?" },
      { n: 11, t: "Explain security awareness and security policy in brief." },
      { n: 12, t: "Write short notes on:\na) Cache memory\nb) IoT" }
    ]}
  ],
  2080: [
    { title: "Section A", instruction: "Attempt any two questions.", questions: [
      { n: 1, t: "Explain hierarchy of different memory types along with figure. What are different types of read only memory?" },
      { n: 2, t: "Compare system software with application software. Explain different types of system software in brief." },
      { n: 3, t: "List some benefits of using computer networks. Explain different types of data transmission media in detail." }
    ]},
    { title: "Section B", instruction: "Attempt any eight questions.", questions: [
      { n: 4, t: "What is digital computer? Compare digital computers with analog computers." },
      { n: 5, t: "Explain each component of CPU in brief." },
      { n: 6, t: "Define hard copy and soft copy devices. List any six human data entry devices." },
      { n: 7, t: "What is ASCII? Convert 0.2345 from base 10 to base 2." },
      { n: 8, t: "Explain wearable computing in brief." },
      { n: 9, t: "Define database. What are the benefits of using databases?" },
      { n: 10, t: "What are different characteristics of multimedia?" },
      { n: 11, t: "Define cryptography. Why do we use firewall?" },
      { n: 12, t: "Write short notes on:\na) Instruction Cycle\nb) BigData" }
    ]}
  ],
  2078: [
    { title: "Section A", instruction: "Attempts any Two Questions", questions: [
      { n: 1, t: "Differentiate analog computer with digital computer. What is CPU and how its works? What does an instruction cycle in CPU consists of?" },
      { n: 2, t: "What is computer Network? Discuss different types of data transmission media in computer network with their advantages and disadvantages." },
      { n: 3, t: "What is database management system? Why database management systems are used. Discuss the database system architecture." }
    ]},
    { title: "Section B", instruction: "Attempts any Eight Questions", questions: [
      { n: 4, t: "What is cache memory? How it is different from register?" },
      { n: 5, t: "Discuss about the source data entry device with example." },
      { n: 6, t: "How binary addition is done? Show binary addition of (11001) with (11011)." },
      { n: 7, t: "What is software? How it differs from hardware? Why software is needed?" },
      { n: 8, t: "Describe the functionalities of operating system." },
      { n: 9, t: "What is internet? Describe about the internet architecture." },
      { n: 10, t: "Define multimedia. Discuss the applications of multimedia." },
      { n: 11, t: "Differentiate security attack from security threat. How virus affects computer?" },
      { n: 12, t: "Write short notes on:\na) GIS\nb) E-commerce" }
    ]}
  ],
  2077: [
    { title: "Section A (2 x 10)", instruction: "Attempt any two questions", questions: [
      { n: 1, t: "Define computer software. Differentiate system software with application software. Explain different types system software in detail." },
      { n: 2, t: "What are the benefits of using computer network? Explain different types of system software in detail. What is network topology?" },
      { n: 3, t: "What is database? What are benefits of using storing database system architectures in detail." }
    ]},
    { title: "Section B", instruction: "Attempt any eight questions", questions: [
      { n: 4, t: "What are different characteristics of computer? Differentiate digital computer with analog computer." },
      { n: 5, t: "What is primary memory? Compare primary memory with secondary memory." },
      { n: 6, t: "Define memory hierarchy. Explain different types of ROM in detail." },
      { n: 7, t: "Explain any two input devices in detail." },
      { n: 8, t: "Convert (110101.101)2 to decimal" },
      { n: 9, t: "Define IP address. Why do we need this address? Compare IPv4 address with IPv6 address." },
      { n: 10, t: "What are different elements of multimedia? Explain" },
      { n: 11, t: "What is cryptography? How does cryptography provide security to our data?" },
      { n: 12, t: "Write short notes on:\na) Central Processing Unit\nb) IoT" }
    ]}
  ],
  2075: [
    { title: "Group A (3 x 10)", instruction: "Attempt any two questions", questions: [
      { n: 1, t: "Discuss the concept behind the fixed point number representation. What can be the fixed point representation of a signed number 8? Convert (14.14)10 into binary and octal." },
      { n: 2, t: "What is switching? How can you differentiate packet switching from circuit switching? What are the advantages of using optical fibers?" },
      { n: 3, t: "Why system software is needed in computers? Discuss various types of operating system." }
    ]},
    { title: "Group B (8 x 5)", instruction: "Attempt any eight questions", questions: [
      { n: 4, t: "What is the role of Control Unit in CPU? How analog computer differs from digital?" },
      { n: 5, t: "How RISC architecture differs from CISC architecture?" },
      { n: 6, t: "What is the purpose of cache memory? How sequential access differs from direct access?" },
      { n: 7, t: "Explain the working mechanism of a keyboard." },
      { n: 8, t: "Why IP address is used in internet? Mention the significance of domain names in internet" },
      { n: 9, t: "Define computer network. Suppose you have a two story building having 15 computers in each of two floors. Now if you are asked to create a network of these computers, what type of network will you create? Give proper justification to your answer." },
      { n: 10, t: "What is malicious software? How virus differs from worms?" },
      { n: 11, t: "Discuss the characteristics of multimedia." },
      { n: 12, t: "What is database system? How data can be stored using relational model." }
    ]}
  ],
  2074: [
    { title: "Group A", instruction: "Attempt any two Questions (2 x 10 = 20)", questions: [
      { n: 1, t: "What is communication protocol? Discuss the OSI model with its layers." },
      { n: 2, t: "What is the objective of using operating system? How operating system performs process, memory and file management activities." },
      { n: 3, t: "What is data model? How ER-Model can be used to create conceptual data model? Explain with example." }
    ]},
    { title: "Group B", instruction: "Attempt any eight Questions (8 x 5 = 40)", questions: [
      { n: 4, t: "What is computer system? Discuss components of computer system." },
      { n: 5, t: "Why bus is used in computer? How control bus differs from data bus?" },
      { n: 6, t: "How many number of bytes are equivalent 1 kilobyte? Discuss the working mechanism of magnetic tape." },
      { n: 7, t: "Mention the use of plotter. How quality of printer is determined?" },
      { n: 8, t: "What do you mean by Internet of Things (IoT)? As an IT expert, mention the possible applications of IoT that you have observed in Nepal." },
      { n: 9, t: "Define each of the terms confidentiality, integrity, and authentication." },
      { n: 10, t: "What is multimedia? Discuss the applications of multimedia." },
      { n: 11, t: "What is BigData? How centralized database is different than the distributed database?" },
      { n: 12, t: "Convert (10.4)10 to binary. Add (10111)2 with (01111)2." }
    ]}
  ]
};

const dir = "BSc_CSIT_1st_Semester_Output/CSC114_Introduction_to_Information_Technology";
fs.mkdirSync(dir, { recursive: true });

(async () => {
  for (const [year, sections] of Object.entries(iit)) {
    const buf = await makeDoc("Introduction to Information Technology", "CSC114", "Computer Science and Information Technology", year, sections);
    const f = dir + "/1st_Semester_CSC114_Introduction_to_Information_Technology_" + year + ".docx";
    fs.writeFileSync(f, buf);
    console.log("Created:", f);
  }
  console.log("IIT done!");
})();
