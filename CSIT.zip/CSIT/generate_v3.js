const fs = require('fs');
const path = require('path');
const { Document, Packer, Paragraph, TextRun, AlignmentType, TabStopType, HeadingLevel } = require('docx');

const BASE_URL = 'https://hamrocsit.com';
const SEMESTERS = {
  2: { name: 'Second', folder: 'BSc_CSIT_2nd_Semester_Output',
    subjects: { 'CSC165': { name: 'Discrete Structure', slug: 'ds' }, 'CSC166': { name: 'Object-Oriented Programming', slug: 'oops' }, 'CSC167': { name: 'Microprocessor', slug: 'microprocessor' }, 'MTH168': { name: 'Mathematics II', slug: 'mathii' }, 'STA169': { name: 'Statistics I', slug: 'stat-i' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  3: { name: 'Third', folder: 'BSc_CSIT_3rd_Semester_Output',
    subjects: { 'CSC211': { name: 'Data Structure and Algorithm', slug: 'dsa' }, 'CSC212': { name: 'Numerical Method', slug: 'csc207' }, 'CSC213': { name: 'Computer Architecture', slug: 'csc208' }, 'CSC214': { name: 'Computer Graphics', slug: 'csc209' }, 'STA215': { name: 'Statistics II', slug: 'stat-ii' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  4: { name: 'Fourth', folder: 'BSc_CSIT_4th_Semester_Output',
    subjects: { 'CSC262': { name: 'Theory of Computation', slug: 'toc' }, 'CSC263': { name: 'Computer Networks', slug: 'cn' }, 'CSC264': { name: 'Operating System', slug: 'os' }, 'CSC265': { name: 'Database Management System', slug: 'dbms' }, 'CSC266': { name: 'Artificial Intelligence', slug: 'ai' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  5: { name: 'Fifth', folder: 'BSc_CSIT_5th_Semester_Output',
    subjects: { 'CSC314': { name: 'Design and Analysis of Algorithms', slug: 'daa' }, 'CSC315': { name: 'System Analysis and Design', slug: 'sad' }, 'CSC316': { name: 'Cryptography', slug: 'cryptography' }, 'CSC317': { name: 'Simulation and Modeling', slug: 'sm' }, 'CSC318': { name: 'Web Technology', slug: 'web-tech' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  6: { name: 'Sixth', folder: 'BSc_CSIT_6th_Semester_Output',
    subjects: { 'CSC364': { name: 'Software Engineering', slug: 'se' }, 'CSC365': { name: 'Compiler Design and Construction', slug: 'cdc' }, 'CSC366': { name: 'E-Governance', slug: 'e-governance' }, 'CSC367': { name: 'NET Centric Computing', slug: 'ncc' }, 'CSC370': { name: 'E-Commerce', slug: 'e-commerce' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  7: { name: 'Seventh', folder: 'BSc_CSIT_7th_Semester_Output',
    subjects: { 'CSC409': { name: 'Advanced Java Programming', slug: 'advanced-java' }, 'CSC410': { name: 'Data Warehousing and Data Mining', slug: 'data-mining' }, 'CSC412': { name: 'Project Work', slug: 'project-work' }, 'CSC413': { name: 'Information Retrieval', slug: 'information-retrieval' }, 'CSC415': { name: 'Software Project Management', slug: 'software-project-management' }, 'CSC416': { name: 'Network Security', slug: 'network-security' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] },
  8: { name: 'Eight', folder: 'BSc_CSIT_8th_Semester_Output',
    subjects: { 'CSC461': { name: 'Advanced Database', slug: 'advanced-database' }, 'CSC463': { name: 'Advanced Networking with IPV6', slug: 'advanced-networking-with-ipv6' }, 'CSC465': { name: 'Game Technology', slug: 'game-technology' }, 'CSC467': { name: 'Introduction to Cloud Computing', slug: 'introduction-to-cloud-computing' }, 'CSC470': { name: 'Mobile Application Development', slug: 'mobile-application-development' }, 'CSC471': { name: 'Real Time Systems', slug: 'real-time-systems' } },
    years: ['2082','2081','2080','2080-new','2079','2078','2076','2075'] }
};

function decodeEntities(t) {
  return t.replace(/&#8211;/g,'\u2013').replace(/&#8212;/g,'\u2014').replace(/&#8216;/g,'\u2018')
    .replace(/&#8217;/g,'\u2019').replace(/&#8220;/g,'\u201C').replace(/&#8221;/g,'\u201D')
    .replace(/&#8230;/g,'\u2026').replace(/&#8722;/g,'\u2212').replace(/&#8710;/g,'\u2206')
    .replace(/&#8747;/g,'\u222B').replace(/&#8734;/g,'\u221E').replace(/&#8736;/g,'\u2220')
    .replace(/&#8804;/g,'\u2264').replace(/&#8805;/g,'\u2265').replace(/&#8800;/g,'\u2260')
    .replace(/&#8712;/g,'\u2208').replace(/&#8713;/g,'\u2209').replace(/&#8838;/g,'\u2286')
    .replace(/&#8839;/g,'\u2287').replace(/&#8836;/g,'\u2285').replace(/&#8745;/g,'\u2229')
    .replace(/&#8746;/g,'\u222A').replace(/&#8733;/g,'\u221D').replace(/&#8776;/g,'\u2248')
    .replace(/&#8764;/g,'\u223C').replace(/&#8855;/g,'\u2295').replace(/&#8857;/g,'\u2299')
    .replace(/&#960;/g,'\u03C0').replace(/&#945;/g,'\u03B1').replace(/&#946;/g,'\u03B2')
    .replace(/&#947;/g,'\u03B3').replace(/&#948;/g,'\u03B4').replace(/&#949;/g,'\u03B5')
    .replace(/&#951;/g,'\u03B7').replace(/&#952;/g,'\u03B8').replace(/&#955;/g,'\u03BB')
    .replace(/&#956;/g,'\u03BC').replace(/&#963;/g,'\u03C3').replace(/&#964;/g,'\u03C4')
    .replace(/&#966;/g,'\u03C6').replace(/&#969;/g,'\u03C9').replace(/&#8364;/g,'\u20AC')
    .replace(/&#\d+;/g,'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
    .replace(/&nbsp;/g,' ').replace(/&quot;/g,'"').trim();
}

function stripHtml(html) {
  let t = html;
  // Convert KaTeX mathml to text
  t = t.replace(/<span class="katex"><span class="katex-mathml">(.*?)<\/span><span class="katex-html"[\s\S]*?<\/span><\/span>/gi, '$1');
  t = t.replace(/<span class="katex">(.*?)<\/span>/gi, '$1');
  // Convert subscripts and superscripts
  t = t.replace(/<sub>(.*?)<\/sub>/gi, '_$1');
  t = t.replace(/<sup>(.*?)<\/sup>/gi, '^$1');
  // Convert line breaks and paragraphs
  t = t.replace(/<br\s*\/?>/gi, '\n');
  t = t.replace(/<\/p>/gi, '\n');
  t = t.replace(/<\/div>/gi, '\n');
  t = t.replace(/<\/li>/gi, '\n');
  // Remove remaining HTML tags
  t = t.replace(/<[^>]+>/g, '');
  // Decode entities
  t = decodeEntities(t);
  // Clean whitespace
  t = t.replace(/\n{3,}/g, '\n\n');
  t = t.replace(/[ \t]+/g, ' ');
  return t.trim();
}

function parseQuestions(html) {
  const sections = [];
  const groupRegex = /<div class="qn_group[^"]*">([\s\S]*?)(?=<div class="qn_group|<\/div>\s*<\/div>\s*<\/div>\s*<\/div>\s*<\/div>)/gi;
  let gm;
  while ((gm = groupRegex.exec(html)) !== null) {
    const g = gm[1];
    const sm = g.match(/<strong>(SECTION\s+[A-Z])<\/strong>/i);
    const im = g.match(/<strong>(Attempt any[^<]*|Answer any[^<]*|Write[^<]*)<\/strong>/i);
    const sec = { title: sm ? sm[1] : 'Questions', instruction: im ? stripHtml(im[1]) : '', questions: [] };
    const qr = /<div class="col-md-12 single_question_container[^"]*"[^>]*>([\s\S]*?)(?=<div class="col-md-12 single_question_container|<\/div>\s*<\/div>\s*<\/div>\s*<\/div>)/gi;
    let qm;
    while ((qm = qr.exec(g)) !== null) {
      const numM = qm[1].match(/<div class="qnbank_number">(\d+)<\/div>/);
      const conM = qm[1].match(/<div class="qnbank_content">([\s\S]*?)<\/div>/);
      if (numM && conM) {
        sec.questions.push({ number: parseInt(numM[1]), text: stripHtml(conM[1]) });
      }
    }
    if (sec.questions.length > 0) sections.push(sec);
  }
  if (sections.length === 0) {
    const qr2 = /<div class="qnbank_number">(\d+)<\/div>\s*<div class="qnbank_content">([\s\S]*?)<\/div>/gi;
    const sec = { title: 'Questions', instruction: '', questions: [] };
    let qm2;
    while ((qm2 = qr2.exec(html)) !== null) {
      sec.questions.push({ number: parseInt(qm2[1]), text: stripHtml(qm2[2]) });
    }
    if (sec.questions.length > 0) sections.push(sec);
  }
  return sections;
}

function formatQuestionText(text) {
  let t = text;
  // Fix subscripts: a_n, a_{n-1}, etc.
  t = t.replace(/_(\{[^}]+\})/g, '$1');
  t = t.replace(/_([0-9])/g, (m, p1) => String.fromCharCode(0x2080 + parseInt(p1)));
  // Fix superscripts
  t = t.replace(/\^(\{[^}]+\})/g, '$1');
  t = t.replace(/\^([0-9])/g, (m, p1) => String.fromCharCode(0x2070 + parseInt(p1)));
  // Clean up extra spaces
  t = t.replace(/\s+/g, ' ').trim();
  return t;
}

async function genDocx(semNum, code, name, year, sections) {
  const semName = SEMESTERS[semNum].name;
  const ch = [];
  
  // Title spacing
  ch.push(new Paragraph({ spacing: { after: 60 }, children: [] }));
  
  // University header
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 },
    children: [new TextRun({ text: 'Tribhuvan University', bold: true, size: 32, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 },
    children: [new TextRun({ text: 'Institute of Science and Technology', bold: true, size: 28, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 },
    children: [new TextRun({ text: 'Bachelor Level / ' + semName.toLowerCase() + ' semester / Science', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 },
    children: [new TextRun({ text: 'Computer Science and Information Technology (' + code + ')', bold: true, size: 24, font: 'Times New Roman' })] }));
  
  // Subject name
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 },
    children: [new TextRun({ text: name, bold: true, size: 32, font: 'Times New Roman' })] }));
  
  // Year
  const yd = year.includes('new') ? year.split('-')[0] + ' (New Syllabus)' : year;
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 },
    children: [new TextRun({ text: yd + ' (BS)', bold: true, size: 28, font: 'Times New Roman' })] }));
  
  // Question Bank label
  ch.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 },
    children: [new TextRun({ text: 'Question Bank', bold: true, size: 26, font: 'Times New Roman' })] }));
  
  // Exam info with proper spacing
  ch.push(new Paragraph({ spacing: { after: 40 },
    children: [new TextRun({ text: 'Full Marks: 60 + 20 + 20', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 40 },
    children: [new TextRun({ text: 'Pass Marks: 24 + 8 + 8', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 40 },
    children: [new TextRun({ text: 'Time: 3 Hours', size: 24, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 160 },
    children: [new TextRun({ text: 'Candidates are required to give their answers in their own words as far as practicable.', italics: true, size: 22, font: 'Times New Roman' })] }));
  ch.push(new Paragraph({ spacing: { after: 200 },
    children: [new TextRun({ text: 'The figures in the margin indicate full marks.', italics: true, size: 22, font: 'Times New Roman' })] }));
  
  // Sections and questions
  for (const sec of sections) {
    // Section title with proper spacing
    ch.push(new Paragraph({ spacing: { before: 240, after: 80 },
      children: [new TextRun({ text: sec.title, bold: true, size: 26, font: 'Times New Roman' })] }));
    
    if (sec.instruction) {
      ch.push(new Paragraph({ spacing: { after: 120 },
        children: [new TextRun({ text: sec.instruction, italics: true, size: 24, font: 'Times New Roman' })] }));
    }
    
    // Questions
    for (const q of sec.questions) {
      let qText = formatQuestionText(q.text);
      
      // Split into paragraphs if there are line breaks
      const paragraphs = qText.split('\n').filter(p => p.trim());
      
      if (paragraphs.length > 0) {
        // First line with question number
        ch.push(new Paragraph({
          spacing: { after: 60 },
          tabStops: [{ type: TabStopType.LEFT, position: 720 }],
          children: [
            new TextRun({ text: q.number + '.', bold: true, size: 24, font: 'Times New Roman' }),
            new TextRun({ text: '\t', size: 24 }),
            new TextRun({ text: paragraphs[0], size: 24, font: 'Times New Roman' })
          ]
        }));
        
        // Remaining lines as indented paragraphs
        for (let i = 1; i < paragraphs.length; i++) {
          ch.push(new Paragraph({
            spacing: { after: 40 },
            indent: { left: 720 },
            children: [new TextRun({ text: paragraphs[i].trim(), size: 24, font: 'Times New Roman' })]
          }));
        }
      }
      
      // Add spacing between questions
      ch.push(new Paragraph({ spacing: { after: 80 }, children: [] }));
    }
  }
  
  const doc = new Document({
    sections: [{
      properties: {
        page: {
          margin: { top: 1440, right: 1296, bottom: 1440, left: 1296 }
        }
      },
      children: ch
    }]
  });
  return doc;
}

async function run() {
  const base = 'C:\\Users\\Acer\\Desktop\\CSIT';
  let total = 0, errs = 0;
  const errList = [];
  
  for (const [sn, sd] of Object.entries(SEMESTERS)) {
    const sf = path.join(base, sd.folder);
    if (!fs.existsSync(sf)) fs.mkdirSync(sf, { recursive: true });
    console.log('\n=== SEMESTER ' + sn + ': ' + sd.name.toUpperCase() + ' ===');
    
    for (const [code, subj] of Object.entries(sd.subjects)) {
      const sdir = path.join(sf, code + '_' + subj.name.replace(/\s+/g, '_'));
      if (!fs.existsSync(sdir)) fs.mkdirSync(sdir, { recursive: true });
      console.log('\n  ' + code + ' - ' + subj.name + ':');
      
      for (const year of sd.years) {
        const url = BASE_URL + '/semester/' + sd.name.toLowerCase() + '/' + subj.slug + '/question-bank/' + year + '/';
        process.stdout.write('    ' + year + '... ');
        
        try {
          const resp = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' } });
          if (!resp.ok) {
            console.log('SKIP (' + resp.status + ')');
            errList.push(sn + '/' + code + ' ' + year + ': HTTP ' + resp.status);
            errs++;
            continue;
          }
          
          const html = await resp.text();
          const sections = parseQuestions(html);
          
          if (sections.length === 0) {
            console.log('NO DATA');
            errList.push(sn + '/' + code + ' ' + year + ': No questions');
            errs++;
            continue;
          }
          
          const tq = sections.reduce((s, sec) => s + sec.questions.length, 0);
          const doc = await genDocx(parseInt(sn), code, subj.name, year, sections);
          const yc = year.replace('-', '_');
          const fn = sd.name + '_Semester_' + code + '_' + subj.name.replace(/\s+/g, '_') + '_' + yc + '.docx';
          const buf = await Packer.toBuffer(doc);
          fs.writeFileSync(path.join(sdir, fn), buf);
          console.log('OK (' + tq + 'Q, ' + (buf.length/1024).toFixed(1) + 'KB)');
          total++;
          
          await new Promise(r => setTimeout(r, 300));
        } catch (e) {
          console.log('ERROR: ' + e.message);
          errList.push(sn + '/' + code + ' ' + year + ': ' + e.message);
          errs++;
        }
      }
    }
  }
  
  console.log('\n=== DONE ===');
  console.log('Files: ' + total + ', Errors: ' + errs);
  if (errList.length > 0) {
    console.log('\nFailed:');
    errList.forEach(e => console.log('  - ' + e));
  }
}

run().catch(console.error);
