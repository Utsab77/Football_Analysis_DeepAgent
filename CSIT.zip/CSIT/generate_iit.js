const docx = require("docx");
const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle, PageBreak } = docx;

const questions = {
  2081: {
    sections: [
      { title: "SECTION A", instruction: "Attempt any TWO questions.", questions: [
        { num: 1, text: "Compare primary memory with secondary memory. Why do we need primary memory in computers? Explain different types of secondary memories used in computer." },
        { num: 2, text: "Explain application software with example. Why do we need system software in computer?What are different type of operating system?" },
        { num: 3, text: "Define network topology. Explain different types of network topologies along with their merit and demerit." }
      ]},
      { title: "SECTION B", instruction: "Attempt any EIGHT questions.", questions: [
        { num: 4, text: "Explain different characteristics of computers." },
        { num: 5, text: "Explain instruction format with example. What is instruction set?" },
        { num: 6, text: "What is I/O port? Explain working of I/O system." },
        { num: 7, text: "What is Unicode? Convert 0.865 from Base 10 to Base 16." },
        { num: 8, text: "Explain cloud computing in brief." },
        { num: 9, text: "What is data warehouse? Explain." },
        { num: 10, text: "What are different element of multimedia?" },
        { num: 11, text: "Explain security awareness and security policy in brief." },
        { num: 12, text: "Write short notes on:", subparts: ["Cache memory", "IoT"] }
      ]}
    ]
  },
  2080: {
    sections: [
      { title: "Section A", instruction: "Attempt any two questions.", questions: [
        { num: 1, text: "Explain hierarchy of different memory types along with figure. What are different types of read only memory?" },
        { num: 2, text: "Compare system software with application software. Explain different types of system software in brief." },
        { num: 3, text: "List some benefits of using computer networks. Explain different types of data transmission media in detail." }
      ]},
      { title: "Section B", instruction: "Attempt any eight questions.", questions: [
        { num: 4, text: "What is digital computer? Compare digital computers with analog computers." },
        { num: 5, text: "Explain each component of CPU in brief." },
        { num: 6, text: "Define hard copy and soft copy devices. List any six human data entry devices." },
        { num: 7, text: "What is ASCII? Convert 0.2345 from base 10 to base 2." },
        { num: 8, text: "Explain wearable computing in brief." },
        { num: 9, text: "Define database. What are the benefits of using databases?" },
        { num: 10, text: "What are different characteristics of multimedia?" },
        { num: 11, text: "Define cryptography. Why do we use firewall?" },
        { num: 12, text: "Write short notes on:", subparts: ["Instruction Cycle", "BigData"] }
      ]}
    ]
  },
  2078: {
    sections: [
      { title: "Section A", instruction: "Attempts any Two Questions", questions: [
        { num: 1, text: "Differentiate analog computer with digital computer. What is CPU and how its works? What does an instruction cycle in CPU consists of?" },
        { num: 2, text: "What is computer Network? Discuss different types of data transmission media in computer network with their advantages and disadvantages." },
        { num: 3, text: "What is database management system? Why database management systems are used. Discuss the database system architecture." }
      ]},
      { title: "Section B", instruction: "Attempts any Eight Questions", questions: [
        { num: 4, text: "What is cache memory? How it is different from register?" },
        { num: 5, text: "Discuss about the source data entry device with example." },
        { num: 6, text: "How binary addition is done? Show binary addition of (11001) with (11011)." },
        { num: 7, text: "What is software? How it differs from hardware? Why software is needed?" },
        { num: 8, text: "Describe the functionalities of operating system." },
        { num: 9, text: "What is internet? Describe about the internet architecture." },
        { num: 10, text: "Define multimedia. Discuss the applications of multimedia." },
        { num: 11, text: "Differentiate security attack from security threat. How virus affects computer?" },
        { num: 12, text: "Write short notes on:", subparts: ["GIS", "E-commerce"] }
      ]}
    ]
  },
  2077: {
    sections: [
      { title: "Section A (2 x 10)", instruction: "Attempt any two questions", questions: [
        { num: 1, text: "Define computer software. Differentiate system software with application software. Explain different types system software in detail." },
        { num: 2, text: "What are the benefits of using computer network? Explain different types of system software in detail. What is network topology?" },
        { num: 3, text: "What is database? What are benefits of using storing database system architectures in detail." }
      ]},
      { title: "Section B", instruction: "Attempt any eight questions", questions: [
        { num: 4, text: "What are different characteristics of computer? Differentiate digital computer with analog computer." },
        { num: 5, text: "What is primary memory? Compare primary memory with secondary memory." },
        { num: 6, text: "Define memory hierarchy. Explain different types of ROM in detail." },
        { num: 7, text: "Explain any two input devices in detail." },
        { num: 8, text: "Convert (110101.101)2 to decimal" },
        { num: 9, text: "Define IP address. Why do we need this address? Compare IPv4 address with IPv6 address." },
        { num: 10, text: "What are different elements of multimedia? Explain" },
        { num: 11, text: "What is cryptography? How does cryptography provide security to our data?" },
        { num: 12, text: "Write short notes on:", subparts: ["Central Processing Unit", "IoT"] }
      ]}
    ]
  },
  2075: {
    sections: [
      { title: "Group A (3 x 10)", instruction: "Attempt any two questions", questions: [
        { num: 1, text: "Discuss the concept behind the fixed point number representation. What can be the fixed point representation of a signed number 8? Convert (14.14)10 into binary and octal." },
        { num: 2, text: "What is switching? How can you differentiate packet switching from circuit switching? What are the advantages of using optical fibers?" },
        { num: 3, text: "Why system software is needed in computers? Discuss various types of operating system." }
      ]},
      { title: "Group B (8 x 5)", instruction: "Attempt any eight questions", questions: [
        { num: 4, text: "What is the role of Control Unit in CPU? How analog computer differs from digital?" },
        { num: 5, text: "How RISC architecture differs from CISC architecture?" },
        { num: 6, text: "What is the purpose of cache memory? How sequential access differs from direct access?" },
        { num: 7, text: "Explain the working mechanism of a keyboard." },
        { num: 8, text: "Why IP address is used in internet? Mention the significance of domain names in internet" },
        { num: 9, text: "Define computer network. Suppose you have a two story building having 15 computers in each of two floors. Now if you are asked to create a network of these computers, what type of network will you create? Give proper justification to your answer." },
        { num: 10, text: "What is malicious software? How virus differs from worms?" },
        { num: 11, text: "Discuss the characteristics of multimedia." },
        { num: 12, text: "What is database system? How data can be stored using relational model." }
      ]}
    ]
  },
  2074: {
    sections: [
      { title: "Group A", instruction: "Attempt any two Questions (2 x 10 = 20)", questions: [
        { num: 1, text: "What is communication protocol? Discuss the OSI model with its layers." },
        { num: 2, text: "What is the objective of using operating system? How operating system performs process, memory and file management activities." },
        { num: 3, text: "What is data model? How ER-Model can be used to create conceptual data model? Explain with example." }
      ]},
      { title: "Group B", instruction: "Attempt any eight Questions (8 x 5 = 40)", questions: [
        { num: 4, text: "What is computer system? Discuss components of computer system." },
        { num: 5, text: "Why bus is used in computer? How control bus differs from data bus?" },
        { num: 6, text: "How many number of bytes are equivalent 1 kilobyte? Discuss the working mechanism of magnetic tape." },
        { num: 7, text: "Mention the use of plotter. How quality of printer is determined?" },
        { num: 8, text: "What do you mean by Internet of Things (IoT)? As an IT expert, mention the possible applications of IoT that you have observed in Nepal." },
        { num: 9, text: "Define each of the terms confidentiality, integrity, and authentication." },
        { num: 10, text: "What is multimedia? Discuss the applications of multimedia." },
        { num: 11, text: "What is BigData? How centralized database is different than the distributed database?" },
        { num: 12, text: "Convert (10.4)10 to binary. Add (10111)2 with (01111)2." }
      ]}
    ]
  }
};

async function generate(year, data) {
  const children = [];
  // University header
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Tribhuvan University", bold: true, size: 28 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Institute of Science and Technology", bold: true, size: 24 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: String(year), bold: true, size: 28 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Bachelor Level / first-semester / Science", size: 22 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Computer Science and Information Technology( CSC114 )", bold: true, size: 22 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Introduction to Information Technology", bold: true, size: 26 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Full Marks: 60 + 20 + 20", size: 22 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Pass Marks: 24 + 8 + 8", size: 22 })] }));
  children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "Time: 3 Hours", size: 22 })] }));
  children.push(new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "Candidates are required to give their answers in their own words as far as practicable.", size: 20, italics: true })] }));
  children.push(new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "The figures in the margin indicate full marks.", size: 20, italics: true })] }));

  for (const section of data.sections) {
    children.push(new Paragraph({ spacing: { before: 300, after: 100 }, children: [new TextRun({ text: section.title, bold: true, size: 24 })] }));
    children.push(new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: section.instruction, bold: true, italics: true, size: 22 })] }));
    for (const q of section.questions) {
      children.push(new Paragraph({ spacing: { before: 200, after: 100 }, children: [new TextRun({ text: String(q.num), bold: true, size: 22 })] }));
      children.push(new Paragraph({ spacing: { after: 100 }, indent: { left: 360 }, children: [new TextRun({ text: q.text, size: 22 })] }));
      if (q.subparts) {
        for (let i = 0; i < q.subparts.length; i++) {
          children.push(new Paragraph({ spacing: { after: 50 }, indent: { left: 720 }, children: [new TextRun({ text: `${String.fromCharCode(97+i)}) ${q.subparts[i]}`, size: 22 })] }));
        }
      }
    }
  }

  const doc = new Document({ sections: [{ children }] });
  const buffer = await Packer.toBuffer(doc);
  const dir = "BSc_CSIT_1st_Semester_Output/CSC114_Introduction_to_Information_Technology";
  const fname = `${dir}/1st_Semester_CSC114_Introduction_to_Information_Technology_${year}.docx`;
  fs.writeFileSync(fname, buffer);
  console.log(`Created: ${fname}`);
}

(async () => {
  for (const [year, data] of Object.entries(questions)) {
    await generate(year, data);
  }
  console.log("All IIT files generated!");
})();
